# Variance Reduction Methods for Personalized PageRank Computation

The dataset can be obtained from: http://konect.cc/networks/

Data Format:
e.g. youtube_u.txt
1134890
0	1
0	2
0	3
...

To reproduce the results in this paper, run:

```
bash exp-youtube_u.sh